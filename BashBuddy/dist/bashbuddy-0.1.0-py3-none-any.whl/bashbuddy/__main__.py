"""Entry point for running the daemon module."""
from bashbuddy.daemon import main

if __name__ == "__main__":
    main()
