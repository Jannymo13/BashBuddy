"""Core module for client and configuration."""
