"""CLI module for BashBuddy commands and display."""
